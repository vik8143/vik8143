/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.product;

import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class ProductStorage {
     private ArrayList<Producttemp> stor;

    public ProductStorage() {
        stor = new ArrayList<Producttemp>();
    }
    
    

    public ArrayList<Producttemp> getStor() {
        return stor;
    }
    
    protected void addproduct(Producttemp pro)
    {
        this.stor.add(pro);
    }
    protected void deleteproduct(Producttemp pro)
    {
        this.stor.remove(pro);
    }
}
