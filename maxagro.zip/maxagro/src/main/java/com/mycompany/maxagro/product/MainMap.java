/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.product;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author DELL
 */
public class MainMap {
    HashMap <String,ProductStorage> cartstoragemap;
    private ArrayList<Producttemp> ordersqueuemap;
    HashMap <String,Pendingstorage> pendingordersmap;
    HashMap <String,ProductStorage> succesfulordermap;

    public MainMap() {
        cartstoragemap = new HashMap <String,ProductStorage>();
        ordersqueuemap = new ArrayList<Producttemp>();
        succesfulordermap = new HashMap <String,ProductStorage>();
        pendingordersmap = new HashMap <String,Pendingstorage>();
    }

    public HashMap<String, ProductStorage> getCartstoragemap() {
        return cartstoragemap;
    }

    public ArrayList<Producttemp> getOrdersqueuemap() {
        return ordersqueuemap;
    }

    public HashMap<String, Pendingstorage> getPendingordersmap() {
        return pendingordersmap;
    }

    public HashMap<String, ProductStorage> getSuccesfulordermap() {
        return succesfulordermap;
    }
    public void addcartstoragemapentry(String username)
    {
        ProductStorage stor = new ProductStorage();
        cartstoragemap.put(username, stor);
    }
    public void addordersqueuemap(Producttemp pt)
    {
        ordersqueuemap.add(pt);
    }
    public void addsuccesfulordermap(String username)
    {
        ProductStorage stor = new ProductStorage();
        succesfulordermap.put(username, stor);
    }
    public void addpendingordersmap(String username)
    {
        Pendingstorage stor = new Pendingstorage();
        pendingordersmap.put(username, stor);
    }
    public void removeordersqueuemap(Producttemp pt)
    {
        ordersqueuemap.remove(pt);
    }
    
    
    
}
