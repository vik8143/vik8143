/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.soil;

import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class SoiltempArray {
    private ArrayList<Soiltemp> sar;

    public SoiltempArray() {
        sar = new ArrayList<Soiltemp>();
        
    }

    public ArrayList<Soiltemp> getSar() {
        return sar;
    }
    
    public void addreport(Soiltemp st)
    {
        sar.add(st);
    }
    
    
}
