/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.weather;

import com.mycompany.maxagro.ui.Weather;
import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class Week {
    private String Day;
    private String Temperature;
    private String Precipitation;
    private String Humidity;
    Weathertemp week[] = new Weathertemp[7];
    
    public Week() {
        data();
    }

    public Weathertemp[] getWeek() {
        return week;
    }

    private void data() {
           Day = "monday";
           Temperature = "32degrees";
           Precipitation = "2%";
           Humidity = "22";
           Weathertemp w = new Weathertemp(Day,Temperature,Precipitation,Humidity);
           week[0] = w;
           Day = "tuesday";
           Temperature = "32degrees";
           Precipitation = "2%";
           Humidity = "22";
           Weathertemp w1 = new Weathertemp(Day,Temperature,Precipitation,Humidity);
           week[1] = w1;
           Day = "wednesday";
           Temperature = "32degrees";
           Precipitation = "2%";
           Humidity = "22";
           Weathertemp w2 = new Weathertemp(Day,Temperature,Precipitation,Humidity);
           week[2] = w2;
           Day = "thursday";
           Temperature = "32degrees";
           Precipitation = "2%";
           Humidity = "22";
           Weathertemp w3 = new Weathertemp(Day,Temperature,Precipitation,Humidity);
           week[3] = w3;
           Day = "friday";
           Temperature = "32degrees";
           Precipitation = "2%";
           Humidity = "22";
           Weathertemp w4 = new Weathertemp(Day,Temperature,Precipitation,Humidity);
           week[4] = w4;
           Day = "saturday";
           Temperature = "32degrees";
           Precipitation = "2%";
           Humidity = "22";
           Weathertemp w5 = new Weathertemp(Day,Temperature,Precipitation,Humidity);
           week[5] = w5;
           Day = "sunday";
           Temperature = "32degrees";
           Precipitation = "2%";
           Humidity = "22";
           Weathertemp w6 = new Weathertemp(Day,Temperature,Precipitation,Humidity);
           week[6] = w6;
           

    }

   

    
    
}
