/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.product;

import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class Producttarray {
     private String id;
    private String type;
    private String name;
    private String price;
    private String model;
    private String engine_cc;
    private String hp;
    ArrayList<Producttemp> tractor = new ArrayList<Producttemp>();
    ArrayList<Producttemp> seeds = new ArrayList<Producttemp>();
    ArrayList<Producttemp> fertilizers = new ArrayList<Producttemp>();
    ArrayList<Producttemp> farmingequipment = new ArrayList<Producttemp>();
    ArrayList<Producttemp> Motors = new ArrayList<Producttemp>();

    public Producttarray() {
        tractors();
        seeds();
        fertilizers();
        farmingequipment();
        motors();
    }

    public ArrayList<Producttemp> getTractor() {
        return tractor;
    }

    public void setTractor(ArrayList<Producttemp> tractor) {
        this.tractor = tractor;
    }

    public ArrayList<Producttemp> getSeeds() {
        return seeds;
    }

    public void setSeeds(ArrayList<Producttemp> seeds) {
        this.seeds = seeds;
    }

    public ArrayList<Producttemp> getFertilizers() {
        return fertilizers;
    }

    public void setFertilizers(ArrayList<Producttemp> fertilizers) {
        this.fertilizers = fertilizers;
    }

    public ArrayList<Producttemp> getFarmingequipment() {
        return farmingequipment;
    }

    public void setFarmingequipment(ArrayList<Producttemp> farmingequipment) {
        this.farmingequipment = farmingequipment;
    }

    public ArrayList<Producttemp> getMotors() {
        return Motors;
    }

    public void setMotors(ArrayList<Producttemp> Motors) {
        this.Motors = Motors;
    }

    private void tractors() {
        id = "231";
        name = "tractor1";
        engine_cc = "2730";
        hp = "30";
        price = "2222";
        Producttemp t1 = new Producttemp(id,name,engine_cc,hp,price);
        tractor.add(t1);
        id = "431";
        name = "tractor2";
        engine_cc = "2220";
        hp = "24";
        price = "2322";
        Producttemp t2 = new Producttemp(id,name,engine_cc,hp,price);
        tractor.add(t2);
        id = "531";
        name = "tractor3";
        engine_cc = "3730";
        hp = "36";
        price = "5222";
        Producttemp t3 = new Producttemp(id,name,engine_cc,hp,price);
        tractor.add(t3);
        
    }

    private void motors() {
        
        id = "1556";
        name = "texmaxtp1";
        type = "submersible";
        hp = "1";
        price = "2222";
        Producttemp t1 = new Producttemp(id,name,type,hp,price);
        Motors.add(t1);
        id = "431";
        name = "zexaxtpl";
        engine_cc = "Multistage4inch";
        hp = "2";
        price = "2322";
        Producttemp t2 = new Producttemp(id,name,engine_cc,hp,price);
        Motors.add(t2);
        id = "530A";
        name = "xpsuperty";
        engine_cc = "douvle booster";
        hp = "4";
        price = "7222";
        Producttemp t3 = new Producttemp(id,name,engine_cc,hp,price);
        Motors.add(t3);
        
    }

    private void farmingequipment() {
        id = "712";
        name = "plows";
        type = "iron";
        price = "235";
        Producttemp s1 = new Producttemp(id,name,type,price);
        farmingequipment.add(s1);
         id = "02";
        name = "planters";
        type = "plastic";
        price = "637";
        Producttemp s2 = new Producttemp(id,name,type,price);
        farmingequipment.add(s2);
         id = "03";
        name = "sprayers";
        type = "plastic";
        price = "46";
        Producttemp s3 = new Producttemp(id,name,type,price);
        farmingequipment.add(s3);
         id = "04";
        name = "balers";
        type = "closed-door horizontal";
        price = "700";
        Producttemp s4 = new Producttemp(id,name,type,price);
        farmingequipment.add(s4);
    }

    private void fertilizers() {
        id = "501";
        name = "FXcr1";
        type = "tomato";
        price = "11";
        Producttemp s1 = new Producttemp(id,name,type,price);
        fertilizers.add(s1);
         id = "502";
        name = "Fxcorngrow";
        type = "corn";
        price = "12";
        Producttemp s2 = new Producttemp(id,name,type,price);
        fertilizers.add(s2);
         id = "203";
        name = "Fxgoodrose";
        type = "roses";
        price = "09";
        Producttemp s3 = new Producttemp(id,name,type,price);
        fertilizers.add(s3);
         id = "304";
        name = "FXstarapple";
        type = "apple";
        price = "09";
        Producttemp s4 = new Producttemp(id,name,type,price);
        fertilizers.add(s4);
    }

    private void seeds() {
        id = "01";
        name = "tomorise";
        type = "tomato";
        price = "23";
        Producttemp s1 = new Producttemp(id,name,type,price);
        seeds.add(s1);
         id = "02";
        name = "babymelon";
        type = "watermelon";
        price = "29";
        Producttemp s2 = new Producttemp(id,name,type,price);
        seeds.add(s2);
         id = "03";
        name = "babypapaya";
        type = "papaya";
        price = "35";
        Producttemp s3 = new Producttemp(id,name,type,price);
        seeds.add(s3);
         id = "04";
        name = "starapple";
        type = "apple";
        price = "12";
        Producttemp s4 = new Producttemp(id,name,type,price);
        seeds.add(s4);
        
                
        
        
    }
    
    
    
}
