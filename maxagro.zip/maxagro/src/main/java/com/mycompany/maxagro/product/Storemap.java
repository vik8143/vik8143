/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.product;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author DELL
 */
public class Storemap {

    public Storemap() {
        Map<String,ProductStorage>mp = new HashMap <String,ProductStorage>();
    }
    
    
}
