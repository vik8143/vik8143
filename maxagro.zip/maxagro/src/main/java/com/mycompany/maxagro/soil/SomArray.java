/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.soil;

import com.mycompany.maxagro.farmer.FarmerTemp;
import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class SomArray {
    private ArrayList<Som> sf;

    public ArrayList<Som> getSf() {
        return sf;
    }

    
    public SomArray() {
        sf = new ArrayList<Som>();
    }
    public void add(Som ft)
    {
        sf.add(ft);
    }
    public void del(Som ft)
    {
        sf.remove(ft);
    }
}
