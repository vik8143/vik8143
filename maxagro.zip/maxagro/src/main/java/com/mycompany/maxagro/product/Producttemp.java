/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.product;

/**
 *
 * @author DELL
 */
public class Producttemp {
    private String id;
    private String type;
    private String name;
    private String price;
    private String hp;
    private String engine_cc;
    private String username;

    public String getUsername() {
        return username;
    }
    

    Producttemp(String id, String name, String engine_cc, String hp, String price) {
        this.id = id;
        this.name = name;
        this.engine_cc = engine_cc;
        this.hp = hp;
        this.price = price;
        this.username = username;
    }

    Producttemp(String id, String name, String type, String price) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.price = price;
        this.username = username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

   

    public String getHp() {
        return hp;
    }

    public void setHp(String hp) {
        this.hp = hp;
    }

    public String getEnginecc() {
        return engine_cc;
    }

    public void setEnginecc(String enginecc) {
        this.engine_cc = enginecc;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

   
    
    
}
