/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.product;

import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class Pendingstorage {
    ArrayList <ProductStorage> pst;

    public Pendingstorage() {
        pst = new ArrayList <ProductStorage>();
    }

    public ArrayList<ProductStorage> getPst() {
        return pst;
    }
    public void addpst(ProductStorage stor)
    {
        pst.add(stor);
    }
    public void delpst(ProductStorage stor)
    {
        pst.remove(stor);
    } 
}
