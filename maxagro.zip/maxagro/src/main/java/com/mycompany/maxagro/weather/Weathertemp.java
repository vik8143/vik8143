/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.weather;

/**
 *
 * @author DELL
 */
public class Weathertemp {
    private String Day;
    private String Temperature;
    private String Precipitation;
    private String Humidity;

    public Weathertemp(String Day, String Temperature, String Precipitation, String Humidity) {
        this.Day = Day;
        this.Temperature = Temperature;
        this.Precipitation = Precipitation;
        this.Humidity = Humidity;
    }

    public String getDay() {
        return Day;
    }

    public void setDay(String Day) {
        this.Day = Day;
    }

    public String getTemperature() {
        return Temperature;
    }

    public void setTemperature(String Temperature) {
        this.Temperature = Temperature;
    }

    public String getPrecipitation() {
        return Precipitation;
    }

    public void setPrecipitation(String Precipitation) {
        this.Precipitation = Precipitation;
    }

    public String getHumidity() {
        return Humidity;
    }

    public void setHumidity(String Humidity) {
        this.Humidity = Humidity;
    }
}
