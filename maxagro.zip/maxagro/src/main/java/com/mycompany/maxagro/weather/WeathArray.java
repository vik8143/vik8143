/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.weather;

import com.mycompany.maxagro.farmer.FarmerTemp;
import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class WeathArray {
    private ArrayList<Weath> sf;

    public WeathArray() {
        sf = new ArrayList<Weath>();
    }

    public ArrayList<Weath> getSf() {
        return sf;
    }
    
    public void add(Weath ft)
    {
        sf.add(ft);
    }
    public void del(Weath ft)
    {
        sf.remove(ft);
    }
    
}
