/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.supplier;

import com.mycompany.maxagro.farmer.FarmerTemp;
import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class Suppliertemparray {
    private ArrayList<Suppliertemp> suf;

    public Suppliertemparray() {
        suf = new ArrayList<Suppliertemp>();
    }

    public ArrayList<Suppliertemp> getSuf() {
        return suf;
    }
    
    public void add(Suppliertemp su)
    {
        suf.add(su);
    }
    public void del(Suppliertemp su)
    {
        suf.remove(su);
    }
}
