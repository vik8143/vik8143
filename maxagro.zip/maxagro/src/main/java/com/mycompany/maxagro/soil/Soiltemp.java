/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.soil;

import java.util.Date;

/**
 *
 * @author DELL
 */
public class Soiltemp {
    private Date date;
    private String name;
    private String nitrogen;
    private String phosphorus;
    private String pottasium;

    public Soiltemp(Date date, String name,String nitrogen, String phosphorus, String pottasium) {
        this.date = date;
        this.name = name;
        this.nitrogen = nitrogen;
        this.phosphorus = phosphorus;
        this.pottasium = pottasium;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getNitrogen() {
        return nitrogen;
    }

    public void setNitrogen(String nitrogen) {
        this.nitrogen = nitrogen;
    }

    public String getPhosphorus() {
        return phosphorus;
    }

    public void setPhosphorus(String phosphorus) {
        this.phosphorus = phosphorus;
    }

    public String getPottasium() {
        return pottasium;
    }

    public void setPottasium(String pottasium) {
        this.pottasium = pottasium;
    }
    
    
}
