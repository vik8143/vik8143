/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.maxagro.soil;

import com.mycompany.maxagro.farmer.FarmerTemp;
import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class Soilrequest {
    
    private ArrayList<FarmerTemp> sf;

    public Soilrequest() {
        sf = new ArrayList<FarmerTemp>();
    }
    public void add(FarmerTemp ft)
    {
        sf.add(ft);
    }
    public void del(FarmerTemp ft)
    {
        sf.remove(ft);
    }

    public ArrayList<FarmerTemp> getSf() {
        return sf;
    }
    
    
}
